package com.sanoarulislam.auth_authorization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthAuthorizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
